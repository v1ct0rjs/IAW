<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Profesores</title>
</head>
<body>
    <h1>Menú Academia</h1>
    <button onclick="window.location.href='insertar_profesor.php'">Insertar Profesor</button>
    <button onclick="window.location.href='mostrar_profesor.php'">Mostrar lista profesores</button>
    <button onclick="window.location.href='eliminar_profesor.php'">Eliminar profesorer</button>
</body>
</html>