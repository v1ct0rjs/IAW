<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $valor1 = 0;
        $valor2 = 0;
        $valor3 = 0;
        $valor4 = 2;
        $valor1 = $valor1 + 1;
        echo $valor1;
        $valor2++;
        echo "<br>";
        echo $valor2;
        $valor3+=1;
        echo "<br>";
        echo $valor3;
        $valor4*=2;
        echo "<br>";
        echo $valor4;
        echo "---------------";

        ?>
        
        <?php 
        $dato1 = 9;
        $dato2 = 9;
        //decrementa con -- dato1
        
        echo "<br>";
        echo $dato1;
        //divide por 3 con la forma corta el dato2 
        
        echo "<br>";
        echo $dato2;
        
     
                
        ?>
    </body>
</html>
